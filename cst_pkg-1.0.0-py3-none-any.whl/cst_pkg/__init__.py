def fun():
    print('Hello there!')